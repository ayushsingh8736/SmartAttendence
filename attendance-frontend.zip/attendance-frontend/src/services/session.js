// Keeps the login session in the browser so a page refresh does not log the user out.
// NOTE: localStorage can be read by any script running on the page. For production,
// consider httpOnly cookies set by the backend.
const KEY = 'attendance_session';

export function getSession() {
  try {
    return JSON.parse(localStorage.getItem(KEY)) || null;
  } catch {
    return null;
  }
}
export function saveSession(session) {
  localStorage.setItem(KEY, JSON.stringify(session));
}
export function clearSession() {
  localStorage.removeItem(KEY);
}
