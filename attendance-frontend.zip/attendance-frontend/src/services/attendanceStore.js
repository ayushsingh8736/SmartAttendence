// PHASE 1 ONLY: saves attendance in the browser (localStorage) so you can test the screens.
// In Phase 4 these functions are replaced by calls to the Spring Boot API:
//   POST /api/teacher/attendance  and  GET /api/teacher/attendance
// The real duplicate check must ALSO exist in the backend and MySQL
// (UNIQUE key on student + subject + date).
const KEY = 'attendance_demo_records';

const read = () => {
  try {
    return JSON.parse(localStorage.getItem(KEY)) || {};
  } catch {
    return {};
  }
};
const write = (data) => localStorage.setItem(KEY, JSON.stringify(data));
const keyOf = (classId, date) => `${classId}|${date}`;

export function getRecord(classId, date) {
  return read()[keyOf(classId, date)] || null;
}

export function listRecords() {
  return Object.values(read()).sort((a, b) => b.date.localeCompare(a.date));
}

// Returns { ok:false, reason:'DUPLICATE' } if a record already exists and updates are not allowed.
export function saveRecord(classId, date, statuses, by, { allowUpdate = false } = {}) {
  const data = read();
  const key = keyOf(classId, date);
  const existing = data[key];
  if (existing && !allowUpdate) return { ok: false, reason: 'DUPLICATE' };

  data[key] = {
    classId,
    date,
    statuses,
    markedBy: existing ? existing.markedBy : by,
    audit: [...(existing ? existing.audit : []), { at: new Date().toISOString(), by, action: existing ? 'UPDATED' : 'CREATED' }],
  };
  write(data);
  return { ok: true, updated: Boolean(existing) };
}
