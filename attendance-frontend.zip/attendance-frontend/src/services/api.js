import axios from 'axios';
import { DEMO_ACCOUNTS } from '../data/mockData.js';
import { clearSession, getSession } from './session.js';

export const USE_MOCK = import.meta.env.VITE_USE_MOCK !== 'false';

export const http = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || '',
  timeout: 15000,
});

// Send the JWT token (if any) with every request.
http.interceptors.request.use((config) => {
  const session = getSession();
  if (session?.token) config.headers.Authorization = `Bearer ${session.token}`;
  return config;
});

// If the token expired or is invalid, log out and go to the login page.
http.interceptors.response.use(
  (response) => response,
  (error) => {
    const isLogin = error.config?.url?.includes('/api/auth/login');
    if (error.response?.status === 401 && !isLogin) {
      clearSession();
      window.location.assign('/login');
    }
    return Promise.reject(error);
  },
);

const wait = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

export function normalizeRole(raw) {
  const value = Array.isArray(raw) ? raw[0] : raw;
  const role = String(value || '').trim().toUpperCase();
  return role.startsWith('ROLE_') ? role.slice(5) : role;
}

function friendlyError(error) {
  if (!error.response) return 'Cannot reach the server. Check your internet connection and make sure the backend is running.';
  const { status, data } = error.response;
  if (status === 400 || status === 401) return 'Incorrect ID/email or password.';
  if (status === 403) return 'Your account is not allowed to log in. Contact the administrator.';
  if (status >= 500) return 'The server had a problem. Please try again later.';
  return data?.message || 'Login failed. Please try again.';
}

// The user never picks a role: the backend returns it, and the app opens the matching dashboard.
export async function login(identifier, password) {
  if (USE_MOCK) {
    await wait(500);
    const id = identifier.trim().toLowerCase();
    const account = DEMO_ACCOUNTS.find((a) => (a.loginId.toLowerCase() === id || a.email === id) && a.password === password);
    if (!account) throw new Error('Incorrect ID/email or password.');
    const { password: _ignored, ...user } = account;
    return { token: 'demo-token', user };
  }

  try {
    // Expected response: { token, userId, name, role, department }
    const { data } = await http.post('/api/auth/login', { username: identifier.trim(), password });
    return {
      token: data.token,
      user: {
        userId: data.userId ?? data.id,
        name: data.name,
        email: data.email,
        role: normalizeRole(data.role),
        department: data.department,
      },
    };
  } catch (error) {
    throw new Error(friendlyError(error));
  }
}

export async function forgotPassword(identifier) {
  if (USE_MOCK) {
    await wait(600);
    return 'Demo mode: no email is sent. In the real app a reset link goes to your registered email.';
  }
  try {
    await http.post('/api/auth/forgot-password', { username: identifier.trim() });
    return 'If this account exists, a password reset link has been sent to the registered email.';
  } catch (error) {
    throw new Error(friendlyError(error));
  }
}
