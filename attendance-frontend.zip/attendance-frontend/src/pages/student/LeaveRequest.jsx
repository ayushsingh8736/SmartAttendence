import FormPage from '../../components/FormPage.jsx';
import { Badge } from '../../components/Badge.jsx';
import { studentLeaves } from '../../data/mockData.js';

// Students can only SUBMIT a request (status always starts as PENDING).
// They cannot approve it: approval belongs to the teacher/coordinator and is enforced by the backend.
export default function LeaveRequest() {
  return (
    <FormPage
      title="Leave Request"
      subtitle="Submit a new request. Earlier requests and their status are listed below."
      submitLabel="Submit request"
      successMessage="Leave request submitted. Status: Pending."
      fields={[
        { name: 'type', label: 'Leave type', type: 'select', options: ['Medical', 'Personal', 'Family', 'Other'] },
        { name: 'from', label: 'From date', type: 'date' },
        { name: 'to', label: 'To date', type: 'date' },
        { name: 'reason', label: 'Reason', type: 'textarea' },
      ]}
      validate={(v) => (v.to < v.from ? 'The "To" date cannot be before the "From" date.' : null)}
      initialRows={studentLeaves}
      buildRow={(v, rows) => ({ id: rows.length + 1, ...v, status: 'PENDING' })}
      columns={[
        { key: 'from', label: 'From' },
        { key: 'to', label: 'To' },
        { key: 'type', label: 'Type' },
        { key: 'reason', label: 'Reason' },
        { key: 'status', label: 'Status', render: (r) => <Badge value={r.status} /> },
      ]}
    />
  );
}
