import { useState } from 'react';
import { studentTimetable } from '../../data/mockData.js';

const DAYS = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

// Shows one day or the full week. Used by the student, coordinator and HOD.
export default function Timetable({ title = 'Timetable', slots = studentTimetable }) {
  const todayName = new Date().toLocaleDateString('en-US', { weekday: 'long' });
  const [view, setView] = useState(DAYS.includes(todayName) ? todayName : 'Monday');
  const showClass = slots.some((s) => s.className);
  const shown = view === 'Week' ? slots : slots.filter((s) => s.day === view);

  return (
    <>
      <h1 className="page-title">{title}</h1>
      <div className="chips" role="tablist" aria-label="Choose a day">
        {[...DAYS, 'Week'].map((d) => (
          <button key={d} type="button" role="tab" aria-selected={view === d} className={`chip ${view === d ? 'active' : ''}`} onClick={() => setView(d)}>
            {d === 'Week' ? 'Full week' : d.slice(0, 3)}
          </button>
        ))}
      </div>
      <section className="card">
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                {view === 'Week' && <th scope="col">Day</th>}
                <th scope="col">Time</th>
                <th scope="col">Subject</th>
                {showClass && <th scope="col">Class</th>}
                <th scope="col">Teacher</th>
                <th scope="col">Room</th>
              </tr>
            </thead>
            <tbody>
              {shown.length === 0 ? (
                <tr><td colSpan="6" className="empty">No classes scheduled.</td></tr>
              ) : shown.map((s) => (
                <tr key={`${s.day}-${s.start}-${s.subject}`}>
                  {view === 'Week' && <td data-label="Day">{s.day}</td>}
                  <td data-label="Time">{s.start} - {s.end}</td>
                  <td data-label="Subject">{s.subject}</td>
                  {showClass && <td data-label="Class">{s.className}</td>}
                  <td data-label="Teacher">{s.teacher}</td>
                  <td data-label="Room">{s.room}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </>
  );
}
