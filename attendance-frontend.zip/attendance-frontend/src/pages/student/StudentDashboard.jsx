import { Link } from 'react-router-dom';
import { Bar } from '../../components/StatCard.jsx';
import StatCard from '../../components/StatCard.jsx';
import { LOW_ATTENDANCE_LIMIT } from '../../config.js';
import { useAuth } from '../../context/AuthContext.jsx';
import { notifications, studentSubjects } from '../../data/mockData.js';
import { pct, prettyDate } from '../../utils/format.js';

export default function StudentDashboard() {
  const { user } = useAuth();
  const total = studentSubjects.reduce((s, x) => s + x.total, 0);
  const attended = studentSubjects.reduce((s, x) => s + x.attended, 0);
  const overall = pct(attended, total);
  const low = studentSubjects.filter((s) => pct(s.attended, s.total) < LOW_ATTENDANCE_LIMIT);

  return (
    <>
      <h1 className="page-title">Welcome, {user.name.split(' ')[0]}!</h1>
      <p className="muted">Overall attendance: <strong>{overall}%</strong></p>

      {low.length > 0 && (
        <div className="alert warn" role="alert">
          Attendance is below {LOW_ATTENDANCE_LIMIT}% in: {low.map((s) => s.name).join(', ')}.
        </div>
      )}

      <div className="grid">
        <StatCard icon="&#128202;" label="Overall Attendance" value={`${overall}%`} tone={overall >= LOW_ATTENDANCE_LIMIT ? 'green' : 'red'} />
        <StatCard icon="&#128218;" label="Total Classes" value={total} />
        <StatCard icon="&#9989;" label="Attended" value={attended} tone="green" />
        <StatCard icon="&#10060;" label="Absent" value={total - attended} tone="red" />
      </div>

      <section className="card">
        <h2>My Subjects</h2>
        {studentSubjects.map((s) => {
          const p = pct(s.attended, s.total);
          return (
            <div key={s.code} className="subject-row">
              <span className="subject-name">{s.name}</span>
              <Bar value={p} />
              <strong className="subject-pct">{p}%</strong>
            </div>
          );
        })}
      </section>

      <div className="actions">
        <Link className="btn" to="/student/attendance">My Attendance</Link>
        <Link className="btn" to="/student/timetable">Timetable</Link>
        <Link className="btn" to="/student/leave">Leave Request</Link>
        <Link className="btn" to="/student/notifications">Notifications</Link>
      </div>

      <section className="card">
        <h2>Recent updates</h2>
        <ul className="plain-list">
          {notifications.slice(0, 3).map((n) => (
            <li key={n.title}><strong>{n.title}</strong> <span className="muted">- {prettyDate(n.date)}</span></li>
          ))}
        </ul>
      </section>
    </>
  );
}
