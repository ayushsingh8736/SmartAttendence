import { Bar } from '../../components/StatCard.jsx';
import DataPage from '../../components/DataPage.jsx';
import { Badge, PctBadge } from '../../components/Badge.jsx';
import { LOW_ATTENDANCE_LIMIT } from '../../config.js';
import { studentSubjects } from '../../data/mockData.js';
import { pct } from '../../utils/format.js';

// Classes still needed to reach the minimum: attended + n >= limit% of (total + n)
export const classesNeeded = (attended, total) => {
  const r = LOW_ATTENDANCE_LIMIT / 100;
  return Math.max(0, Math.ceil((r * total - attended) / (1 - r)));
};

export const subjectRows = studentSubjects.map((s) => ({
  ...s, pct: pct(s.attended, s.total), absent: s.total - s.attended, needed: classesNeeded(s.attended, s.total),
}));

export default function MyAttendance() {
  const columns = [
    { key: 'name', label: 'Subject' },
    { key: 'total', label: 'Total' },
    { key: 'attended', label: 'Attended' },
    { key: 'absent', label: 'Absent' },
    { key: 'bar', label: 'Progress', render: (r) => <Bar value={r.pct} /> },
    { key: 'pct', label: 'Percentage', render: (r) => <PctBadge value={r.pct} /> },
    { key: 'status', label: 'Status', render: (r) => <Badge value={r.pct >= LOW_ATTENDANCE_LIMIT ? 'SAFE' : 'LOW'} /> },
  ];
  return (
    <DataPage title="My Attendance" subtitle="Subject-wise attendance" columns={columns} rows={subjectRows}
      searchable={false} exportName="my-attendance" />
  );
}
