import { Link } from 'react-router-dom';
import StatCard from '../../components/StatCard.jsx';
import { DEMO_ACCOUNTS, departments } from '../../data/mockData.js';

export default function AdminDashboard() {
  return (
    <>
      <h1 className="page-title">Admin Panel</h1>
      <div className="grid">
        <StatCard icon="&#128100;" label="User Accounts" value={DEMO_ACCOUNTS.length} />
        <StatCard icon="&#127970;" label="Departments" value={departments.length} />
        <StatCard icon="&#127891;" label="Students" value={departments.reduce((s, d) => s + d.students, 0)} />
        <StatCard icon="&#128105;&#8205;&#127979;" label="Faculty" value={departments.reduce((s, d) => s + d.faculty, 0)} />
      </div>
      <div className="actions">
        <Link className="btn" to="/admin/users">Manage Users</Link>
        <Link className="btn" to="/admin/departments">Departments</Link>
        <Link className="btn" to="/admin/settings">System Settings</Link>
      </div>
    </>
  );
}
