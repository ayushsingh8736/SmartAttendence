import FormPage from '../../components/FormPage.jsx';
import { payments } from '../../data/mockData.js';
import { inr, todayISO } from '../../utils/format.js';

// PHASE 1: the new payment is only added to the list on screen.
// In Phase 4 this form sends POST /api/accountant/payments and the backend creates the receipt.
export default function RecordPayment() {
  return (
    <FormPage
      title="Record Payment"
      submitLabel="Record payment"
      successMessage="Payment recorded."
      fields={[
        { name: 'studentId', label: 'Student ID', type: 'text' },
        { name: 'name', label: 'Student name', type: 'text' },
        { name: 'amount', label: 'Amount (INR)', type: 'number' },
        { name: 'mode', label: 'Payment mode', type: 'select', options: ['UPI', 'Cash', 'Bank transfer', 'Cheque'] },
      ]}
      validate={(v) => (Number(v.amount) <= 0 ? 'Amount must be greater than zero.' : null)}
      initialRows={payments}
      buildRow={(v, rows) => ({ receipt: `RCP-${1000 + rows.length + 1}`, date: todayISO(), ...v, amount: Number(v.amount) })}
      columns={[
        { key: 'receipt', label: 'Receipt' }, { key: 'date', label: 'Date' }, { key: 'studentId', label: 'Student ID' },
        { key: 'name', label: 'Student' }, { key: 'amount', label: 'Amount', render: (r) => inr(r.amount) }, { key: 'mode', label: 'Mode' },
      ]}
    />
  );
}
