import { Link } from 'react-router-dom';
import { Bar } from '../../components/StatCard.jsx';
import StatCard from '../../components/StatCard.jsx';
import { feeSummary, payments } from '../../data/mockData.js';
import { inr, pct } from '../../utils/format.js';

export default function AccountantDashboard() {
  const pending = feeSummary.total - feeSummary.collected;
  const collectedPct = pct(feeSummary.collected, feeSummary.total);
  return (
    <>
      <h1 className="page-title">Accountant Panel</h1>
      <div className="grid">
        <StatCard icon="&#128176;" label="Total Fees" value={inr(feeSummary.total)} />
        <StatCard icon="&#9989;" label="Collected" value={inr(feeSummary.collected)} tone="green" />
        <StatCard icon="&#9203;" label="Pending" value={inr(pending)} tone="orange" />
      </div>
      <section className="card">
        <h2>Collection progress: {collectedPct}%</h2>
        <Bar value={collectedPct} tone="good" />
      </section>
      <div className="actions">
        <Link className="btn" to="/accountant/student-fees">Student Fee Records</Link>
        <Link className="btn" to="/accountant/record-payment">Record Payment</Link>
        <Link className="btn" to="/accountant/payment-history">Payment History</Link>
        <Link className="btn" to="/accountant/receipts">Generate Receipt</Link>
        <Link className="btn" to="/accountant/reports">Fee Reports</Link>
      </div>
      <section className="card">
        <h2>Recent payments</h2>
        <div className="table-wrap">
          <table className="table">
            <thead><tr><th>Receipt</th><th>Date</th><th>Student</th><th>Amount</th><th>Mode</th></tr></thead>
            <tbody>
              {payments.slice(0, 4).map((p) => (
                <tr key={p.receipt}>
                  <td data-label="Receipt">{p.receipt}</td><td data-label="Date">{p.date}</td><td data-label="Student">{p.name}</td>
                  <td data-label="Amount">{inr(p.amount)}</td><td data-label="Mode">{p.mode}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </>
  );
}
