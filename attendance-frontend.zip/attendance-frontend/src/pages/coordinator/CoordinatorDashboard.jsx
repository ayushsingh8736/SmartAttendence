import { Link } from 'react-router-dom';
import { PctBadge } from '../../components/Badge.jsx';
import StatCard from '../../components/StatCard.jsx';
import { coordinatorStats, lowAttendance } from '../../data/mockData.js';

const ACTIONS = [
  ['classes', 'Manage Classes'], ['allocation', 'Assign Teachers'], ['monitoring', 'Attendance Reports'],
  ['low-attendance', 'Low Attendance'], ['timetable', 'Timetable'], ['leave-monitoring', 'Leave Monitoring'],
];

export default function CoordinatorDashboard() {
  const s = coordinatorStats;
  return (
    <>
      <h1 className="page-title">Coordinator Panel</h1>
      <div className="grid">
        <StatCard icon="&#127891;" label="Total Students" value={s.students} />
        <StatCard icon="&#128105;&#8205;&#127979;" label="Total Teachers" value={s.teachers} />
        <StatCard icon="&#127979;" label="Classes" value={s.classes} />
        <StatCard icon="&#9203;" label="Pending Attendance" value={s.pending} tone="orange" />
      </div>
      <div className="actions">
        {ACTIONS.map(([path, label]) => <Link key={path} className="btn" to={`/coordinator/${path}`}>{label}</Link>)}
      </div>
      <section className="card">
        <h2>Students below the attendance limit</h2>
        <div className="table-wrap">
          <table className="table">
            <thead><tr><th>ID</th><th>Student</th><th>Class</th><th>Attendance</th></tr></thead>
            <tbody>
              {lowAttendance.map((r) => (
                <tr key={r.studentId}>
                  <td data-label="ID">{r.studentId}</td><td data-label="Student">{r.name}</td>
                  <td data-label="Class">{r.className}</td><td data-label="Attendance"><PctBadge value={r.pct} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </>
  );
}
