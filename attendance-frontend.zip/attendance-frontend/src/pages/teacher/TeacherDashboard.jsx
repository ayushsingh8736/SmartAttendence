import { Link } from 'react-router-dom';
import { Badge } from '../../components/Badge.jsx';
import StatCard from '../../components/StatCard.jsx';
import { useAuth } from '../../context/AuthContext.jsx';
import { teacherClasses, teacherStudents } from '../../data/mockData.js';
import { getRecord } from '../../services/attendanceStore.js';
import { prettyDate, todayISO } from '../../utils/format.js';

export default function TeacherDashboard() {
  const { user } = useAuth();
  const today = todayISO();
  const rows = teacherClasses.map((c) => ({ ...c, marked: Boolean(getRecord(c.id, today)) }));
  const pending = rows.filter((r) => !r.marked).length;
  const students = teacherClasses.reduce((sum, c) => sum + teacherStudents[c.id].length, 0);

  return (
    <>
      <h1 className="page-title">Welcome, {user.name}</h1>
      <p className="muted">{prettyDate(today)}</p>

      <div className="grid">
        <StatCard icon="&#128197;" label="Today's Classes" value={rows.length} />
        <StatCard icon="&#9203;" label="Pending Attendance" value={pending} tone={pending ? 'orange' : 'green'} />
        <StatCard icon="&#128101;" label="My Students" value={students} />
      </div>

      <section className="card">
        <h2>Today's classes</h2>
        <div className="table-wrap">
          <table className="table">
            <thead><tr><th>Time</th><th>Class</th><th>Subject</th><th>Room</th><th>Attendance</th><th><span className="sr-only">Action</span></th></tr></thead>
            <tbody>
              {rows.map((c) => (
                <tr key={c.id}>
                  <td data-label="Time">{c.time}</td>
                  <td data-label="Class">{c.className}</td>
                  <td data-label="Subject">{c.subject}</td>
                  <td data-label="Room">{c.room}</td>
                  <td data-label="Attendance"><Badge value={c.marked ? 'MARKED' : 'PENDING'} /></td>
                  <td><Link className="btn small" to={`/teacher/mark-attendance?class=${c.id}`}>{c.marked ? 'View / Edit' : 'Mark'}</Link></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <div className="actions">
        <Link className="btn" to="/teacher/mark-attendance">Mark Attendance</Link>
        <Link className="btn" to="/teacher/history">Attendance History</Link>
        <Link className="btn" to="/teacher/reports">Reports</Link>
      </div>
    </>
  );
}
