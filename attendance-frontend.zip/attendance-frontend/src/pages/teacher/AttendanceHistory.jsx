import { useMemo } from 'react';
import DataPage from '../../components/DataPage.jsx';
import { PctBadge } from '../../components/Badge.jsx';
import { teacherClasses, teacherHistorySeed } from '../../data/mockData.js';
import { listRecords } from '../../services/attendanceStore.js';
import { pct } from '../../utils/format.js';

export default function AttendanceHistory() {
  // Sessions saved on the Mark Attendance screen + sample older sessions.
  const rows = useMemo(() => {
    const saved = listRecords().map((rec) => {
      const c = teacherClasses.find((x) => x.id === rec.classId);
      const values = Object.values(rec.statuses);
      return {
        date: rec.date, className: c.className, subject: c.subject,
        present: values.filter((v) => v === 'PRESENT').length,
        absent: values.filter((v) => v === 'ABSENT').length,
        late: values.filter((v) => v === 'LATE').length,
      };
    });
    return [...saved, ...teacherHistorySeed]
      .map((r) => ({ ...r, pct: pct(r.present + r.late, r.present + r.absent + r.late) }))
      .sort((a, b) => b.date.localeCompare(a.date));
  }, []);

  const columns = [
    { key: 'date', label: 'Date' },
    { key: 'className', label: 'Class' },
    { key: 'subject', label: 'Subject' },
    { key: 'present', label: 'Present' },
    { key: 'absent', label: 'Absent' },
    { key: 'late', label: 'Late' },
    { key: 'pct', label: 'Attendance', render: (r) => <PctBadge value={r.pct} /> },
  ];
  return <DataPage title="Attendance History" subtitle="Late students count as attended." columns={columns} rows={rows} filterKey="className" filterLabel="Class" />;
}
