import { useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { EDIT_WINDOW_DAYS } from '../../config.js';
import { useAuth } from '../../context/AuthContext.jsx';
import { teacherClasses, teacherStudents } from '../../data/mockData.js';
import { getRecord, saveRecord } from '../../services/attendanceStore.js';
import { prettyDate, todayISO } from '../../utils/format.js';

const OPTIONS = [['PRESENT', 'Present'], ['ABSENT', 'Absent'], ['LATE', 'Late']];

export default function MarkAttendance() {
  const { user } = useAuth();
  const [params] = useSearchParams();
  const initialClass = teacherClasses.some((c) => c.id === params.get('class')) ? params.get('class') : teacherClasses[0].id;

  const [classId, setClassId] = useState(initialClass);
  const [date, setDate] = useState(todayISO());
  const [statuses, setStatuses] = useState({});
  const [existing, setExisting] = useState(null);
  const [editing, setEditing] = useState(false);
  const [message, setMessage] = useState(null);

  const cls = teacherClasses.find((c) => c.id === classId);
  const students = useMemo(() => teacherStudents[classId], [classId]);

  // Whenever class or date changes: load a saved record, or start with everyone present.
  useEffect(() => {
    const record = getRecord(classId, date);
    setExisting(record);
    setEditing(false);
    setMessage(null);
    setStatuses(record ? record.statuses : Object.fromEntries(students.map((s) => [s.id, 'PRESENT'])));
  }, [classId, date, students]);

  const ageDays = Math.floor((new Date(`${todayISO()}T00:00:00`) - new Date(`${date}T00:00:00`)) / 86400000);
  const locked = Boolean(existing) && ageDays > EDIT_WINDOW_DAYS;
  const readOnly = Boolean(existing) && !editing;

  const counts = { PRESENT: 0, ABSENT: 0, LATE: 0 };
  students.forEach((s) => { counts[statuses[s.id] || 'PRESENT'] += 1; });

  const setAll = () => setStatuses(Object.fromEntries(students.map((s) => [s.id, 'PRESENT'])));

  const save = () => {
    const result = saveRecord(classId, date, statuses, user.name, { allowUpdate: editing });
    if (!result.ok) {
      setMessage({ type: 'error', text: 'Attendance for this class and date is already saved. Use Edit to correct it.' });
      return;
    }
    setExisting(getRecord(classId, date));
    setEditing(false);
    setMessage({
      type: 'success',
      text: result.updated ? 'Attendance updated. The change was recorded in the audit log.' : 'Attendance saved successfully.',
    });
  };

  return (
    <>
      <h1 className="page-title">Mark Attendance</h1>

      <section className="card form-grid">
        <label>
          <span className="label">Class and subject</span>
          <select className="input" value={classId} onChange={(e) => setClassId(e.target.value)}>
            {teacherClasses.map((c) => <option key={c.id} value={c.id}>{c.className} - {c.subject}</option>)}
          </select>
        </label>
        <label>
          <span className="label">Date</span>
          <input className="input" type="date" value={date} max={todayISO()} onChange={(e) => e.target.value && setDate(e.target.value)} />
        </label>
      </section>

      {existing && (
        <div className={`alert ${locked ? 'bad' : 'warn'}`} role="status">
          {locked
            ? `Attendance for ${prettyDate(date)} is locked (older than ${EDIT_WINDOW_DAYS} days). Ask the coordinator or HOD to approve a correction.`
            : `Attendance for ${prettyDate(date)} is already saved by ${existing.markedBy}. ${editing ? 'You are editing it.' : 'Press Edit to correct it.'}`}
        </div>
      )}

      <section className="card">
        <p className="muted">{cls.className} | {cls.subject} | {prettyDate(date)}</p>
        <div className="toolbar">
          <button type="button" className="btn outline" onClick={setAll} disabled={readOnly}>Select All Present</button>
          <span className="count good">Present: {counts.PRESENT}</span>
          <span className="count bad">Absent: {counts.ABSENT}</span>
          <span className="count warn">Late: {counts.LATE}</span>
        </div>

        <div className="table-wrap">
          <table className="table">
            <thead><tr><th>Student ID</th><th>Student</th><th>Status</th></tr></thead>
            <tbody>
              {students.map((s) => (
                <tr key={s.id}>
                  <td data-label="Student ID">{s.id}</td>
                  <td data-label="Student">{s.name}</td>
                  <td data-label="Status">
                    <div className="seg" role="radiogroup" aria-label={`Attendance for ${s.name}`}>
                      {OPTIONS.map(([value, label]) => (
                        <button key={value} type="button" role="radio" aria-checked={statuses[s.id] === value} disabled={readOnly}
                          className={`seg-btn ${value.toLowerCase()} ${statuses[s.id] === value ? 'on' : ''}`}
                          onClick={() => setStatuses({ ...statuses, [s.id]: value })}>
                          {label}
                        </button>
                      ))}
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="actions">
          {!existing && <button type="button" className="btn" onClick={save}>Save Attendance</button>}
          {existing && !editing && !locked && <button type="button" className="btn" onClick={() => setEditing(true)}>Edit Attendance</button>}
          {existing && editing && (
            <>
              <button type="button" className="btn" onClick={save}>Update Attendance</button>
              <button type="button" className="btn outline" onClick={() => { setEditing(false); setStatuses(existing.statuses); }}>Cancel</button>
            </>
          )}
        </div>
        {message && <div className={`alert ${message.type === 'error' ? 'bad' : 'good'}`} role="status">{message.text}</div>}
      </section>
    </>
  );
}
