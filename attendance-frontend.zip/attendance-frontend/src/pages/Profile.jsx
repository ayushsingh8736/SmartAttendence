import { useAuth } from '../context/AuthContext.jsx';

// Shows the details returned by the backend at login.
export default function Profile() {
  const { user } = useAuth();
  const rows = [
    ['Name', user.name],
    ['Role', user.role],
    ['Department', user.department],
    ['Login ID', user.loginId],
    ['Email', user.email],
    ['User ID', user.userId],
  ].filter(([, v]) => v !== undefined && v !== null && v !== '');

  return (
    <>
      <h1 className="page-title">Profile</h1>
      <section className="card profile">
        <div className="avatar" aria-hidden="true">{user.name.charAt(0)}</div>
        <dl>
          {rows.map(([k, v]) => (
            <div key={k} className="profile-row"><dt>{k}</dt><dd>{v}</dd></div>
          ))}
        </dl>
      </section>
    </>
  );
}
