import { Link } from 'react-router-dom';
import BarChart from '../../components/BarChart.jsx';
import { PctBadge } from '../../components/Badge.jsx';
import StatCard from '../../components/StatCard.jsx';
import { hodStats, lowAttendance, semesterAttendance } from '../../data/mockData.js';

export default function HODDashboard() {
  const average = Math.round(semesterAttendance.reduce((s, x) => s + x.value, 0) / semesterAttendance.length);
  return (
    <>
      <h1 className="page-title">HOD Panel</h1>
      <p className="muted">Department: <strong>{hodStats.department}</strong></p>
      <div className="grid">
        <StatCard icon="&#127891;" label="Total Students" value={hodStats.students} />
        <StatCard icon="&#128105;&#8205;&#127979;" label="Total Faculty" value={hodStats.faculty} />
        <StatCard icon="&#128202;" label="Average Attendance" value={`${average}%`} tone="green" />
      </div>
      <section className="card">
        <h2>Attendance by semester</h2>
        <BarChart data={semesterAttendance} title="Average attendance percentage for each semester" />
      </section>
      <div className="actions">
        <Link className="btn" to="/hod/students">Student Reports</Link>
        <Link className="btn" to="/hod/faculty">Faculty Monitoring</Link>
        <Link className="btn" to="/hod/low-attendance">Low Attendance</Link>
        <Link className="btn" to="/hod/approvals">Attendance Approvals</Link>
        <Link className="btn" to="/hod/semesters">Semester Reports</Link>
      </div>
      <section className="card">
        <h2>Low attendance students</h2>
        <div className="table-wrap">
          <table className="table">
            <thead><tr><th>Student</th><th>Class</th><th>Attendance</th></tr></thead>
            <tbody>
              {lowAttendance.map((r) => (
                <tr key={r.studentId}>
                  <td data-label="Student">{r.name}</td><td data-label="Class">{r.className}</td>
                  <td data-label="Attendance"><PctBadge value={r.pct} /></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>
    </>
  );
}
