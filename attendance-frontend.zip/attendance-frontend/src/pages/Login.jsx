import { useState } from 'react';
import { Navigate, useLocation, useNavigate } from 'react-router-dom';
import Logo from '../components/Logo.jsx';
import { useAuth } from '../context/AuthContext.jsx';
import { DEMO_ACCOUNTS } from '../data/mockData.js';
import { forgotPassword, USE_MOCK } from '../services/api.js';

export default function Login() {
  const { user, signIn } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [errors, setErrors] = useState({});
  const [formError, setFormError] = useState('');
  const [loading, setLoading] = useState(false);
  const [forgotOpen, setForgotOpen] = useState(false);
  const [forgotMsg, setForgotMsg] = useState(null);

  // Already logged in: go straight to the dashboard for the saved role.
  if (user) return <Navigate to={`/${user.role.toLowerCase()}`} replace />;

  const onSubmit = async (e) => {
    e.preventDefault();
    if (loading) return; // blocks double submit
    const next = {};
    if (!identifier.trim()) next.identifier = 'Please enter your Email, Employee ID or Student ID.';
    if (!password) next.password = 'Please enter your password.';
    setErrors(next);
    setFormError('');
    if (Object.keys(next).length) return;

    setLoading(true);
    try {
      const loggedIn = await signIn(identifier, password);
      const target = `/${loggedIn.role.toLowerCase()}`;
      const from = location.state?.from?.pathname;
      navigate(from && from.startsWith(target) ? from : target, { replace: true });
    } catch (err) {
      setFormError(err.message || 'Login failed. Please try again.');
      setLoading(false);
    }
  };

  const onForgot = async () => {
    if (!identifier.trim()) return setForgotMsg({ type: 'error', text: 'Type your Email, Employee ID or Student ID above first.' });
    try {
      setForgotMsg({ type: 'success', text: await forgotPassword(identifier) });
    } catch (err) {
      setForgotMsg({ type: 'error', text: err.message });
    }
  };

  return (
    <div className="login-wrap">
      <div className="login-card">
        <Logo showCollege />
        <h1 className="login-title">Sign in</h1>
        <p className="muted">Use your Email, Employee ID or Student ID. Your role is detected automatically.</p>

        <form onSubmit={onSubmit} noValidate>
          <label>
            <span className="label">Email / Employee ID / Student ID</span>
            <input className={`input ${errors.identifier ? 'invalid' : ''}`} type="text" autoComplete="username" autoFocus
              value={identifier} onChange={(e) => setIdentifier(e.target.value)} aria-invalid={Boolean(errors.identifier)} />
            {errors.identifier && <span className="field-error">{errors.identifier}</span>}
          </label>

          <label>
            <span className="label">Password</span>
            <div className="password-row">
              <input className={`input ${errors.password ? 'invalid' : ''}`} type={showPassword ? 'text' : 'password'}
                autoComplete="current-password" value={password} onChange={(e) => setPassword(e.target.value)}
                aria-invalid={Boolean(errors.password)} />
              <button type="button" className="btn outline small" onClick={() => setShowPassword((s) => !s)}
                aria-pressed={showPassword}>{showPassword ? 'Hide' : 'Show'}</button>
            </div>
            {errors.password && <span className="field-error">{errors.password}</span>}
          </label>

          {formError && <div className="alert bad" role="alert">{formError}</div>}

          <button type="submit" className="btn block" disabled={loading}>
            {loading ? <><span className="spinner" aria-hidden="true" /> Signing in...</> : 'Login'}
          </button>
        </form>

        <button type="button" className="link-btn" onClick={() => setForgotOpen((o) => !o)} aria-expanded={forgotOpen}>
          Forgot Password?
        </button>
        {forgotOpen && (
          <div className="forgot">
            <p className="muted">Enter your ID or email in the box above, then press the button.</p>
            <button type="button" className="btn outline" onClick={onForgot}>Send reset link</button>
            {forgotMsg && <div className={`alert ${forgotMsg.type === 'error' ? 'bad' : 'good'}`} role="status">{forgotMsg.text}</div>}
          </div>
        )}

        {USE_MOCK && (
          <details className="demo">
            <summary>Demo accounts (demo mode)</summary>
            <ul>
              {DEMO_ACCOUNTS.map((a) => (
                <li key={a.loginId}>
                  <button type="button" className="link-btn" onClick={() => { setIdentifier(a.loginId); setPassword(a.password); setFormError(''); }}>
                    {a.role}: {a.loginId} / {a.password}
                  </button>
                </li>
              ))}
            </ul>
          </details>
        )}
      </div>
    </div>
  );
}
