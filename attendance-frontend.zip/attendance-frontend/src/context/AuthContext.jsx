import { createContext, useContext, useMemo, useState } from 'react';
import { ROLES } from '../config.js';
import { login } from '../services/api.js';
import { clearSession, getSession, saveSession } from '../services/session.js';

const AuthContext = createContext(null);

function loadValidSession() {
  const session = getSession();
  return session && session.user && ROLES.includes(session.user.role) ? session : null;
}

export function AuthProvider({ children }) {
  const [session, setSession] = useState(loadValidSession);

  const value = useMemo(
    () => ({
      user: session ? session.user : null,
      async signIn(identifier, password) {
        const result = await login(identifier, password);
        if (!ROLES.includes(result.user.role)) {
          throw new Error('Your account does not have a supported role. Contact the administrator.');
        }
        saveSession(result);
        setSession(result);
        return result.user;
      },
      signOut() {
        clearSession();
        setSession(null);
      },
    }),
    [session],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider');
  return ctx;
}
