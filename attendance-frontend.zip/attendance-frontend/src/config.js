// Central settings used across the app.
export const APP_NAME = 'Attendance System';
export const COLLEGE_NAME = 'Your College Name'; // <- put your college name here
export const LOW_ATTENDANCE_LIMIT = 75;          // minimum attendance percentage
export const EDIT_WINDOW_DAYS = 7;               // teachers may correct attendance for this many days

// Role values must match what the Spring Boot backend returns.
export const ROLES = ['STUDENT', 'TEACHER', 'COORDINATOR', 'ACCOUNTANT', 'HOD', 'ADMIN'];
