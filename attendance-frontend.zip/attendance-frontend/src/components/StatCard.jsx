import { LOW_ATTENDANCE_LIMIT } from '../config.js';

export default function StatCard({ label, value, hint, tone = 'blue', icon }) {
  return (
    <div className={`card stat stat-${tone}`}>
      {icon && <div className="stat-icon" aria-hidden="true">{icon}</div>}
      <div>
        <div className="stat-label">{label}</div>
        <div className="stat-value">{value}</div>
        {hint && <div className="stat-hint">{hint}</div>}
      </div>
    </div>
  );
}

export function Bar({ value, tone }) {
  const level = tone || (value < LOW_ATTENDANCE_LIMIT ? 'bad' : 'good');
  return (
    <div className="bar" role="progressbar" aria-valuenow={value} aria-valuemin={0} aria-valuemax={100}>
      <span className={`bar-fill bar-${level}`} style={{ width: `${Math.min(100, Math.max(0, value))}%` }} />
    </div>
  );
}
