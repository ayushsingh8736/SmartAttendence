import { LOW_ATTENDANCE_LIMIT } from '../config.js';

const GOOD = ['PRESENT', 'APPROVED', 'PAID', 'MARKED', 'ACTIVE', 'SAFE'];
const BAD = ['ABSENT', 'REJECTED', 'OVERDUE', 'LOW', 'INACTIVE'];
const WARN = ['LATE', 'PENDING', 'PARTIAL'];

export function toneOf(value) {
  const v = String(value).toUpperCase();
  if (GOOD.includes(v)) return 'good';
  if (BAD.includes(v)) return 'bad';
  if (WARN.includes(v)) return 'warn';
  return 'info';
}

// Coloured label. Colour is never the only signal: the text is always shown too.
export function Badge({ value, tone, children }) {
  return <span className={`badge badge-${tone || toneOf(value)}`}>{children ?? value}</span>;
}

export function PctBadge({ value }) {
  return <Badge tone={value >= LOW_ATTENDANCE_LIMIT ? 'good' : 'bad'}>{value}%</Badge>;
}
