import { LOW_ATTENDANCE_LIMIT } from '../config.js';

// Simple column chart (no chart library needed). data = [{ label, value }] with value 0-100.
export default function BarChart({ data, title }) {
  return (
    <div className="chart" role="img" aria-label={title}>
      {data.map((d) => (
        <div key={d.label} className="chart-col">
          <span className="chart-val">{d.value}%</span>
          <div className="chart-track">
            <div className={`chart-bar ${d.value < LOW_ATTENDANCE_LIMIT ? 'low' : ''}`} style={{ height: `${d.value}%` }} />
          </div>
          <span className="chart-label">{d.label}</span>
        </div>
      ))}
    </div>
  );
}
