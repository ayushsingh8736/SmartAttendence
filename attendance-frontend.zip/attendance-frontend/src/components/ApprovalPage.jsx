import { useState } from 'react';
import { Badge } from './Badge.jsx';
import DataPage from './DataPage.jsx';

// Attendance-correction approvals. PHASE 1: decisions are kept in memory only.
// In Phase 4 each decision is sent to the backend, which must also write an audit log.
export default function ApprovalPage({ title, subtitle, initialRows }) {
  const [rows, setRows] = useState(initialRows);
  const decide = (id, status) => setRows((list) => list.map((r) => (r.id === id ? { ...r, status } : r)));

  const columns = [
    { key: 'date', label: 'Date' },
    { key: 'className', label: 'Class' },
    { key: 'subject', label: 'Subject' },
    { key: 'requestedBy', label: 'Requested by' },
    { key: 'reason', label: 'Reason' },
    { key: 'status', label: 'Status', render: (r) => <Badge value={r.status} /> },
    {
      key: 'actions', label: 'Action',
      render: (r) => (r.status === 'PENDING' ? (
        <div className="row-actions">
          <button type="button" className="btn small" onClick={() => decide(r.id, 'APPROVED')}>Approve</button>
          <button type="button" className="btn small danger" onClick={() => decide(r.id, 'REJECTED')}>Reject</button>
        </div>
      ) : '-'),
    },
  ];

  return <DataPage title={title} subtitle={subtitle} columns={columns} rows={rows} filterKey="status" filterLabel="Status" />;
}
