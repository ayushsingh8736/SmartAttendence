import { NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import Logo from './Logo.jsx';

export default function Sidebar({ items, base, open, onClose }) {
  const { signOut } = useAuth();
  const navigate = useNavigate();

  const logout = () => {
    signOut();
    navigate('/login', { replace: true });
  };

  return (
    <>
      <aside className={`sidebar ${open ? 'open' : ''}`} aria-label="Main navigation">
        <div className="sidebar-brand"><Logo light /></div>
        <nav>
          {items.map((i) => (
            <NavLink
              key={i.path || 'home'}
              to={i.path ? `${base}/${i.path}` : base}
              end={!i.path}
              onClick={onClose}
              className={({ isActive }) => `nav-link ${isActive ? 'active' : ''}`}
            >
              <span aria-hidden="true">{i.icon}</span> {i.label}
            </NavLink>
          ))}
        </nav>
        <button type="button" className="nav-link logout" onClick={logout}>
          <span aria-hidden="true">&#128682;</span> Logout
        </button>
      </aside>
      {open && <div className="overlay" onClick={onClose} aria-hidden="true" />}
    </>
  );
}
