import { useState } from 'react';
import DataPage from './DataPage.jsx';

// A small form on top and the list of saved items below.
// fields = [{ name, label, type: text|number|date|select|textarea, options?, required? }]
export default function FormPage({
  title, subtitle, fields, columns, initialRows, buildRow, validate, submitLabel = 'Submit', successMessage = 'Saved successfully.',
}) {
  const blank = Object.fromEntries(fields.map((f) => [f.name, f.type === 'select' ? f.options[0] : '']));
  const [values, setValues] = useState(blank);
  const [rows, setRows] = useState(initialRows);
  const [message, setMessage] = useState(null);

  const onSubmit = (e) => {
    e.preventDefault();
    const missing = fields.find((f) => f.required !== false && !String(values[f.name]).trim());
    if (missing) return setMessage({ type: 'error', text: `Please fill in: ${missing.label}.` });
    const problem = validate ? validate(values) : null;
    if (problem) return setMessage({ type: 'error', text: problem });
    setRows((prev) => [buildRow(values, prev), ...prev]);
    setValues(blank);
    setMessage({ type: 'success', text: successMessage });
  };

  return (
    <DataPage title={title} subtitle={subtitle} columns={columns} rows={rows} searchable={false} exportable={false}>
      <form className="card form-grid" onSubmit={onSubmit} noValidate>
        {fields.map((f) => (
          <label key={f.name} className={f.type === 'textarea' ? 'span-2' : ''}>
            <span className="label">{f.label}</span>
            {f.type === 'select' ? (
              <select className="input" value={values[f.name]} onChange={(e) => setValues({ ...values, [f.name]: e.target.value })}>
                {f.options.map((o) => <option key={o}>{o}</option>)}
              </select>
            ) : f.type === 'textarea' ? (
              <textarea className="input" rows="3" value={values[f.name]} onChange={(e) => setValues({ ...values, [f.name]: e.target.value })} />
            ) : (
              <input className="input" type={f.type} min={f.type === 'number' ? 1 : undefined} value={values[f.name]}
                onChange={(e) => setValues({ ...values, [f.name]: e.target.value })} />
            )}
          </label>
        ))}
        <div className="span-2">
          <button type="submit" className="btn">{submitLabel}</button>
          {message && <div className={`alert ${message.type === 'error' ? 'bad' : 'good'}`} role="status">{message.text}</div>}
        </div>
      </form>
    </DataPage>
  );
}
