import { useMemo, useState } from 'react';
import { downloadCSV } from '../utils/format.js';
import StatCard from './StatCard.jsx';

// One reusable page: title + optional stat cards + searchable, filterable, exportable table.
// columns = [{ key, label, render?(row) }]
export default function DataPage({
  title, subtitle, columns, rows, stats = [], filterKey, filterLabel = 'Filter',
  searchable = true, exportable = true, exportName, empty = 'No records found.', children,
}) {
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState('ALL');

  const options = useMemo(
    () => (filterKey ? ['ALL', ...Array.from(new Set(rows.map((r) => r[filterKey])))] : []),
    [rows, filterKey],
  );

  const shown = useMemo(() => {
    const q = query.trim().toLowerCase();
    return rows.filter((r) => {
      if (filterKey && filter !== 'ALL' && r[filterKey] !== filter) return false;
      return !q || columns.some((c) => String(r[c.key] ?? '').toLowerCase().includes(q));
    });
  }, [rows, query, filter, filterKey, columns]);

  const fileName = `${exportName || title.toLowerCase().replace(/\s+/g, '-')}.csv`;
  const exportCols = columns.filter((c) => c.key !== 'actions');

  return (
    <>
      <h1 className="page-title">{title}</h1>
      {subtitle && <p className="muted">{subtitle}</p>}

      {stats.length > 0 && (
        <div className="grid">
          {stats.map((s) => <StatCard key={s.label} {...s} />)}
        </div>
      )}
      {children}

      <section className="card">
        {(searchable || filterKey || exportable) && (
          <div className="toolbar">
            {searchable && (
              <input type="search" className="input" placeholder="Search..." aria-label="Search table"
                value={query} onChange={(e) => setQuery(e.target.value)} />
            )}
            {filterKey && (
              <select className="input" aria-label={filterLabel} value={filter} onChange={(e) => setFilter(e.target.value)}>
                {options.map((o) => <option key={o} value={o}>{o === 'ALL' ? `All (${filterLabel})` : o}</option>)}
              </select>
            )}
            {exportable && (
              <>
                <button type="button" className="btn outline" onClick={() => downloadCSV(fileName, exportCols, shown)}>Export CSV</button>
                <button type="button" className="btn outline" onClick={() => window.print()}>Print / PDF</button>
              </>
            )}
          </div>
        )}

        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>{columns.map((c) => <th key={c.key} scope="col">{c.label}</th>)}</tr>
            </thead>
            <tbody>
              {shown.length === 0 ? (
                <tr><td colSpan={columns.length} className="empty">{empty}</td></tr>
              ) : (
                shown.map((r, i) => (
                  <tr key={r.id ?? `${i}-${r[columns[0].key]}`}>
                    {columns.map((c) => <td key={c.key} data-label={c.label}>{c.render ? c.render(r) : r[c.key]}</td>)}
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </section>
    </>
  );
}
