import { APP_NAME, COLLEGE_NAME } from '../config.js';

export default function Logo({ light = false, showCollege = false }) {
  return (
    <div className={`logo ${light ? 'logo-light' : ''}`}>
      <img src="/logo.svg" alt="College logo" width="36" height="36" />
      <div>
        <div className="logo-name">{APP_NAME}</div>
        {showCollege && <div className="logo-college">{COLLEGE_NAME}</div>}
      </div>
    </div>
  );
}
