import { Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import Logo from './Logo.jsx';

export default function Navbar({ onMenu, notifPath, notifCount }) {
  const { user } = useAuth();
  return (
    <header className="navbar">
      <button type="button" className="icon-btn menu-btn" aria-label="Open menu" onClick={onMenu}>&#9776;</button>
      <Logo />
      <div className="spacer" />
      {notifPath && (
        <Link to={notifPath} className="icon-btn" aria-label={`Notifications, ${notifCount} new`}>
          <span aria-hidden="true">&#128276;</span>
          {notifCount > 0 && <span className="dot">{notifCount}</span>}
        </Link>
      )}
      <div className="user-chip">
        <strong>{user.name}</strong>
        <small>{user.role}</small>
      </div>
    </header>
  );
}
