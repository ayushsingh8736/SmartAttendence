import { useState } from 'react';
import { Outlet, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';
import { notifications } from '../data/mockData.js';
import { ROLE_ROUTES } from '../roleConfig.jsx';
import Navbar from './Navbar.jsx';
import Sidebar from './Sidebar.jsx';

// Shared frame for every role: sidebar (drawer on mobile) + top bar + page content.
export default function Layout() {
  const { user } = useAuth();
  const { pathname } = useLocation();
  const [open, setOpen] = useState(false);

  const items = ROLE_ROUTES[user.role];
  const base = `/${user.role.toLowerCase()}`;
  const hasNotifications = items.some((i) => i.path === 'notifications');

  return (
    <div className="app">
      <Sidebar items={items} base={base} open={open} onClose={() => setOpen(false)} />
      <div className="main">
        <Navbar
          onMenu={() => setOpen(true)}
          notifPath={hasNotifications ? `${base}/notifications` : null}
          notifCount={notifications.length}
        />
        <main className="content">
          {/* key = remount on every page change so search/filter boxes start clean */}
          <Outlet key={pathname} />
        </main>
      </div>
    </div>
  );
}
