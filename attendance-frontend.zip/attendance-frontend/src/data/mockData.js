// PHASE 1 DEMO DATA (fictional). Replace with real API calls in Phase 4.
// Every percentage shown in the app is calculated from these numbers.

// Demo logins. In real mode (VITE_USE_MOCK=false) these are NOT used.
export const DEMO_ACCOUNTS = [
  { loginId: 'STU2024001', email: 'ayush.singh@college.edu', password: 'student123', userId: 101, name: 'Ayush Singh', role: 'STUDENT', department: 'BCA' },
  { loginId: 'EMP1001', email: 'rohan.verma@college.edu', password: 'teacher123', userId: 201, name: 'Rohan Verma', role: 'TEACHER', department: 'BCA' },
  { loginId: 'EMP2001', email: 'neha.gupta@college.edu', password: 'coord123', userId: 301, name: 'Neha Gupta', role: 'COORDINATOR', department: 'BCA' },
  { loginId: 'EMP3001', email: 'sanjay.kumar@college.edu', password: 'account123', userId: 401, name: 'Sanjay Kumar', role: 'ACCOUNTANT', department: 'Accounts' },
  { loginId: 'EMP4001', email: 'anita.sharma@college.edu', password: 'hod12345', userId: 501, name: 'Dr. Anita Sharma', role: 'HOD', department: 'Computer Applications' },
  { loginId: 'ADMIN01', email: 'admin@college.edu', password: 'admin123', userId: 1, name: 'System Admin', role: 'ADMIN', department: 'Administration' },
];

/* ------------------------------ STUDENT ------------------------------ */
export const studentSubjects = [
  { code: 'BCA401', name: 'Java', teacher: 'Rohan Verma', total: 30, attended: 27 },
  { code: 'BCA402', name: 'DBMS', teacher: 'Priya Nair', total: 25, attended: 20 },
  { code: 'BCA403', name: 'DAA', teacher: 'Karan Joshi', total: 24, attended: 17 },
  { code: 'BCA404', name: 'Computer Networks', teacher: 'Sunita Rao', total: 21, attended: 18 },
];

export const studentHistory = [
  { date: '2026-10-26', subject: 'Java', status: 'PRESENT' },
  { date: '2026-10-26', subject: 'DBMS', status: 'PRESENT' },
  { date: '2026-10-23', subject: 'DAA', status: 'ABSENT' },
  { date: '2026-10-23', subject: 'Computer Networks', status: 'PRESENT' },
  { date: '2026-10-22', subject: 'Java', status: 'PRESENT' },
  { date: '2026-10-22', subject: 'DBMS', status: 'LATE' },
  { date: '2026-10-21', subject: 'DAA', status: 'PRESENT' },
  { date: '2026-10-21', subject: 'Computer Networks', status: 'ABSENT' },
  { date: '2026-10-20', subject: 'Java', status: 'PRESENT' },
  { date: '2026-10-20', subject: 'DBMS', status: 'PRESENT' },
  { date: '2026-10-19', subject: 'DAA', status: 'ABSENT' },
  { date: '2026-10-19', subject: 'Computer Networks', status: 'PRESENT' },
];

export const studentTimetable = [
  { day: 'Monday', start: '09:00', end: '10:00', subject: 'Java', teacher: 'Rohan Verma', room: 'A-101' },
  { day: 'Monday', start: '10:00', end: '11:00', subject: 'DBMS', teacher: 'Priya Nair', room: 'A-101' },
  { day: 'Tuesday', start: '09:00', end: '10:00', subject: 'DAA', teacher: 'Karan Joshi', room: 'A-101' },
  { day: 'Tuesday', start: '10:00', end: '11:00', subject: 'Computer Networks', teacher: 'Sunita Rao', room: 'A-101' },
  { day: 'Wednesday', start: '09:00', end: '10:00', subject: 'Java', teacher: 'Rohan Verma', room: 'A-101' },
  { day: 'Wednesday', start: '11:00', end: '12:00', subject: 'DBMS', teacher: 'Priya Nair', room: 'A-101' },
  { day: 'Thursday', start: '09:00', end: '10:00', subject: 'DAA', teacher: 'Karan Joshi', room: 'A-101' },
  { day: 'Thursday', start: '10:00', end: '11:00', subject: 'Computer Networks', teacher: 'Sunita Rao', room: 'A-101' },
  { day: 'Friday', start: '09:00', end: '10:00', subject: 'Java', teacher: 'Rohan Verma', room: 'A-101' },
  { day: 'Friday', start: '10:00', end: '11:00', subject: 'DBMS', teacher: 'Priya Nair', room: 'A-101' },
  { day: 'Saturday', start: '09:00', end: '10:00', subject: 'DAA', teacher: 'Karan Joshi', room: 'A-101' },
];

export const studentLeaves = [
  { id: 1, from: '2026-09-12', to: '2026-09-13', type: 'Medical', reason: 'Fever and rest advised', status: 'APPROVED' },
  { id: 2, from: '2026-10-05', to: '2026-10-05', type: 'Personal', reason: 'Family function', status: 'REJECTED' },
];

export const notifications = [
  { date: '2026-10-26', title: 'Mid-term results published', message: 'Semester 4 mid-term results are available.', from: 'Examination Cell' },
  { date: '2026-10-24', title: 'Attendance reminder', message: 'Students below 75% must meet their class teacher.', from: 'Rohan Verma' },
  { date: '2026-10-22', title: 'Holiday notice', message: 'College will be closed on 25 December and 1 January.', from: 'College Office' },
  { date: '2026-10-20', title: 'Fee due date', message: 'Last date for semester fee payment is 30 November.', from: 'Accounts Department' },
];

/* ------------------------------ TEACHER ------------------------------ */
export const teacherClasses = [
  { id: 'C1', className: 'BCA 4th Semester - A', subject: 'Java', time: '09:00 - 10:00', room: 'A-101' },
  { id: 'C2', className: 'BCA 4th Semester - B', subject: 'Java', time: '11:00 - 12:00', room: 'B-201' },
  { id: 'C3', className: 'BCA 2nd Semester - A', subject: 'Data Structures', time: '14:00 - 15:00', room: 'A-105' },
];

export const teacherStudents = {
  C1: [
    { id: '101', name: 'Ayush Singh' }, { id: '102', name: 'Diya Iyer' }, { id: '103', name: 'Kabir Malhotra' },
    { id: '104', name: 'Ananya Rao' }, { id: '105', name: 'Vihaan Patel' }, { id: '106', name: 'Ishita Desai' },
  ],
  C2: [
    { id: '201', name: 'Rahul Menon' }, { id: '202', name: 'Sneha Kulkarni' }, { id: '203', name: 'Arjun Bhatt' },
    { id: '204', name: 'Meera Joshi' }, { id: '205', name: 'Farhan Sheikh' },
  ],
  C3: [
    { id: '301', name: 'Tanya Arora' }, { id: '302', name: 'Yash Chauhan' }, { id: '303', name: 'Nisha Pillai' },
    { id: '304', name: 'Dev Khanna' }, { id: '305', name: 'Pooja Reddy' },
  ],
};

export const teacherHistorySeed = [
  { date: '2026-10-26', className: 'BCA 4th Semester - A', subject: 'Java', present: 5, absent: 1, late: 0 },
  { date: '2026-10-26', className: 'BCA 4th Semester - B', subject: 'Java', present: 4, absent: 0, late: 1 },
  { date: '2026-10-23', className: 'BCA 2nd Semester - A', subject: 'Data Structures', present: 4, absent: 1, late: 0 },
  { date: '2026-10-22', className: 'BCA 4th Semester - A', subject: 'Java', present: 6, absent: 0, late: 0 },
  { date: '2026-10-21', className: 'BCA 4th Semester - B', subject: 'Java', present: 3, absent: 2, late: 0 },
];

export const teacherSubjects = [
  { code: 'BCA401', subject: 'Java', semester: '4th', classes: 'BCA 4th Semester - A, B' },
  { code: 'BCA203', subject: 'Data Structures', semester: '2nd', classes: 'BCA 2nd Semester - A' },
];

export const teacherLeaveRequests = [
  { student: 'Diya Iyer', className: 'BCA 4th Semester - A', from: '2026-10-27', to: '2026-10-28', reason: 'Medical appointment', status: 'PENDING' },
  { student: 'Arjun Bhatt', className: 'BCA 4th Semester - B', from: '2026-10-20', to: '2026-10-21', reason: 'Family function', status: 'APPROVED' },
  { student: 'Dev Khanna', className: 'BCA 2nd Semester - A', from: '2026-10-15', to: '2026-10-15', reason: 'Personal work', status: 'REJECTED' },
];

export const teacherReports = [
  { className: 'BCA 4th Semester - A', subject: 'Java', sessions: 24, average: 86, lowCount: 1 },
  { className: 'BCA 4th Semester - B', subject: 'Java', sessions: 24, average: 81, lowCount: 1 },
  { className: 'BCA 2nd Semester - A', subject: 'Data Structures', sessions: 20, average: 78, lowCount: 2 },
];

export const teacherStudentPercent = { 101: 90, 102: 84, 103: 68, 104: 88, 105: 95, 106: 79, 201: 82, 202: 91, 203: 73, 204: 85, 205: 77, 301: 80, 302: 71, 303: 88, 304: 69, 305: 90 };

/* ---------------------------- COORDINATOR ---------------------------- */
export const coordinatorStats = { students: 450, teachers: 25, classes: 12, pending: 4 };

export const lowAttendance = [
  { studentId: '103', name: 'Kabir Malhotra', className: 'BCA 4th Semester - A', pct: 68 },
  { studentId: '203', name: 'Arjun Bhatt', className: 'BCA 4th Semester - B', pct: 73 },
  { studentId: '302', name: 'Yash Chauhan', className: 'BCA 2nd Semester - A', pct: 71 },
  { studentId: '304', name: 'Dev Khanna', className: 'BCA 2nd Semester - A', pct: 69 },
  { studentId: '412', name: 'Riya Saxena', className: 'BCA 6th Semester - A', pct: 72 },
];

export const classList = [
  { className: 'BCA 2nd Semester - A', students: 62, classTeacher: 'Karan Joshi', average: 82 },
  { className: 'BCA 2nd Semester - B', students: 58, classTeacher: 'Sunita Rao', average: 85 },
  { className: 'BCA 4th Semester - A', students: 60, classTeacher: 'Rohan Verma', average: 84 },
  { className: 'BCA 4th Semester - B', students: 57, classTeacher: 'Priya Nair', average: 80 },
  { className: 'BCA 6th Semester - A', students: 55, classTeacher: 'Amit Bose', average: 88 },
  { className: 'BCA 6th Semester - B', students: 52, classTeacher: 'Kavita Rao', average: 86 },
];

export const studentDirectory = [
  { id: '101', name: 'Ayush Singh', className: 'BCA 4th Semester - A', status: 'ACTIVE' },
  { id: '102', name: 'Diya Iyer', className: 'BCA 4th Semester - A', status: 'ACTIVE' },
  { id: '103', name: 'Kabir Malhotra', className: 'BCA 4th Semester - A', status: 'ACTIVE' },
  { id: '201', name: 'Rahul Menon', className: 'BCA 4th Semester - B', status: 'ACTIVE' },
  { id: '301', name: 'Tanya Arora', className: 'BCA 2nd Semester - A', status: 'ACTIVE' },
  { id: '412', name: 'Riya Saxena', className: 'BCA 6th Semester - A', status: 'INACTIVE' },
];

export const facultyAllocation = [
  { teacher: 'Rohan Verma', subject: 'Java', className: 'BCA 4th Semester - A, B' },
  { teacher: 'Priya Nair', subject: 'DBMS', className: 'BCA 4th Semester - A, B' },
  { teacher: 'Karan Joshi', subject: 'DAA', className: 'BCA 4th Semester - A' },
  { teacher: 'Sunita Rao', subject: 'Computer Networks', className: 'BCA 4th Semester - A' },
  { teacher: 'Amit Bose', subject: 'Software Engineering', className: 'BCA 6th Semester - A, B' },
];

export const attendanceMonitoring = [
  { className: 'BCA 4th Semester - A', subject: 'Java', teacher: 'Rohan Verma', today: 'MARKED' },
  { className: 'BCA 4th Semester - B', subject: 'DBMS', teacher: 'Priya Nair', today: 'PENDING' },
  { className: 'BCA 2nd Semester - A', subject: 'Data Structures', teacher: 'Karan Joshi', today: 'MARKED' },
  { className: 'BCA 6th Semester - A', subject: 'Software Engineering', teacher: 'Amit Bose', today: 'PENDING' },
];

export const corrections = [
  { id: 1, date: '2026-10-21', className: 'BCA 4th Semester - B', subject: 'Java', requestedBy: 'Rohan Verma', reason: 'Two students marked absent by mistake', status: 'PENDING' },
  { id: 2, date: '2026-10-19', className: 'BCA 2nd Semester - A', subject: 'Data Structures', requestedBy: 'Karan Joshi', reason: 'Late entry after the 7-day edit window', status: 'PENDING' },
  { id: 3, date: '2026-10-15', className: 'BCA 6th Semester - A', subject: 'Software Engineering', requestedBy: 'Amit Bose', reason: 'Wrong date selected', status: 'APPROVED' },
];

export const departmentTimetable = studentTimetable.map((s) => ({ ...s, className: 'BCA 4th Semester - A' }));

export const semesterReports = [
  { semester: '2nd Semester', students: 120, average: 83, lowCount: 9 },
  { semester: '4th Semester', students: 117, average: 82, lowCount: 11 },
  { semester: '6th Semester', students: 107, average: 87, lowCount: 5 },
];

/* ----------------------------- ACCOUNTANT ----------------------------- */
export const feeSummary = { total: 2000000, collected: 1500000 };

export const studentFees = [
  { studentId: '101', name: 'Ayush Singh', className: 'BCA 4th Semester - A', total: 60000, paid: 60000 },
  { studentId: '102', name: 'Diya Iyer', className: 'BCA 4th Semester - A', total: 60000, paid: 30000 },
  { studentId: '103', name: 'Kabir Malhotra', className: 'BCA 4th Semester - A', total: 60000, paid: 0 },
  { studentId: '201', name: 'Rahul Menon', className: 'BCA 4th Semester - B', total: 60000, paid: 45000 },
  { studentId: '301', name: 'Tanya Arora', className: 'BCA 2nd Semester - A', total: 55000, paid: 55000 },
];

export const feeStructure = [
  { course: 'BCA - Year 1', tuition: 45000, exam: 5000, library: 2000 },
  { course: 'BCA - Year 2', tuition: 48000, exam: 5000, library: 2000 },
  { course: 'BCA - Year 3', tuition: 52000, exam: 6000, library: 2000 },
];

export const payments = [
  { receipt: 'RCP-1004', date: '2026-10-26', studentId: '201', name: 'Rahul Menon', amount: 15000, mode: 'UPI' },
  { receipt: 'RCP-1003', date: '2026-10-24', studentId: '102', name: 'Diya Iyer', amount: 30000, mode: 'Bank transfer' },
  { receipt: 'RCP-1002', date: '2026-10-21', studentId: '301', name: 'Tanya Arora', amount: 55000, mode: 'Cash' },
  { receipt: 'RCP-1001', date: '2026-10-19', studentId: '101', name: 'Ayush Singh', amount: 60000, mode: 'UPI' },
];

export const feeReports = [
  { period: 'Today', collected: 15000, transactions: 1 },
  { period: 'This month', collected: 160000, transactions: 4 },
  { period: 'This semester', collected: 1500000, transactions: 96 },
];

export const refunds = [
  { id: 'RF-201', studentId: '412', name: 'Riya Saxena', amount: 12000, reason: 'Admission cancelled', status: 'APPROVED' },
  { id: 'RF-202', studentId: '215', name: 'Sameer Khan', amount: 5000, reason: 'Excess payment', status: 'PENDING' },
];

/* -------------------------------- HOD -------------------------------- */
export const hodStats = { department: 'Computer Applications', students: 450, faculty: 25 };

export const semesterAttendance = [
  { label: 'Sem 1', value: 86 }, { label: 'Sem 2', value: 83 }, { label: 'Sem 3', value: 85 },
  { label: 'Sem 4', value: 82 }, { label: 'Sem 5', value: 88 }, { label: 'Sem 6', value: 87 },
];

export const facultyMonitoring = [
  { teacher: 'Rohan Verma', subjects: 'Java, Data Structures', classes: 3, marked: '23 / 24', status: 'ACTIVE' },
  { teacher: 'Priya Nair', subjects: 'DBMS', classes: 2, marked: '20 / 20', status: 'ACTIVE' },
  { teacher: 'Karan Joshi', subjects: 'DAA', classes: 2, marked: '17 / 20', status: 'PENDING' },
  { teacher: 'Sunita Rao', subjects: 'Computer Networks', classes: 2, marked: '19 / 19', status: 'ACTIVE' },
];

export const subjectReports = [
  { subject: 'Java', classes: 2, average: 84, lowCount: 2 },
  { subject: 'DBMS', classes: 2, average: 80, lowCount: 4 },
  { subject: 'DAA', classes: 1, average: 75, lowCount: 6 },
  { subject: 'Computer Networks', classes: 1, average: 81, lowCount: 3 },
];

/* ------------------------------- ADMIN ------------------------------- */
export const departments = [
  { code: 'BCA', name: 'Computer Applications', hod: 'Dr. Anita Sharma', students: 450, faculty: 25 },
  { code: 'BBA', name: 'Business Administration', hod: 'Dr. Vikram Sethi', students: 380, faculty: 18 },
  { code: 'BCOM', name: 'Commerce', hod: 'Dr. Meena Pillai', students: 410, faculty: 20 },
];

export const systemSettings = [
  { setting: 'Minimum attendance required', value: '75%' },
  { setting: 'Attendance edit window for teachers', value: '7 days' },
  { setting: 'Academic year', value: '2026 - 2027' },
  { setting: 'Password policy', value: 'Minimum 8 characters' },
];
