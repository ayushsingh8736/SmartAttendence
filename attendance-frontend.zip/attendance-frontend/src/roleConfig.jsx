// One place that defines the menu and pages for every role.
// The first item of each role (path '') is that role's dashboard.
import ApprovalPage from './components/ApprovalPage.jsx';
import { Badge, PctBadge } from './components/Badge.jsx';
import DataPage from './components/DataPage.jsx';
import { LOW_ATTENDANCE_LIMIT } from './config.js';
import * as D from './data/mockData.js';
import AdminDashboard from './pages/admin/AdminDashboard.jsx';
import AccountantDashboard from './pages/accountant/AccountantDashboard.jsx';
import RecordPayment from './pages/accountant/RecordPayment.jsx';
import CoordinatorDashboard from './pages/coordinator/CoordinatorDashboard.jsx';
import HODDashboard from './pages/hod/HODDashboard.jsx';
import Profile from './pages/Profile.jsx';
import LeaveRequest from './pages/student/LeaveRequest.jsx';
import MyAttendance, { subjectRows } from './pages/student/MyAttendance.jsx';
import StudentDashboard from './pages/student/StudentDashboard.jsx';
import Timetable from './pages/student/Timetable.jsx';
import AttendanceHistory from './pages/teacher/AttendanceHistory.jsx';
import MarkAttendance from './pages/teacher/MarkAttendance.jsx';
import TeacherDashboard from './pages/teacher/TeacherDashboard.jsx';
import { inr } from './utils/format.js';

const statusCol = { key: 'status', label: 'Status', render: (r) => <Badge value={r.status} /> };
const pctCol = (key, label = 'Attendance') => ({ key, label, render: (r) => <PctBadge value={r[key]} /> });
const money = (key, label) => ({ key, label, render: (r) => inr(r[key]) });

const notificationsPage = (
  <DataPage title="Notifications" columns={[
    { key: 'date', label: 'Date' }, { key: 'title', label: 'Title' }, { key: 'message', label: 'Message' }, { key: 'from', label: 'From' },
  ]} rows={D.notifications} exportable={false} />
);

const lowAttendancePage = (
  <DataPage title="Low Attendance Report" subtitle={`Students below ${LOW_ATTENDANCE_LIMIT}%`} filterKey="className" filterLabel="Class"
    columns={[{ key: 'studentId', label: 'ID' }, { key: 'name', label: 'Student' }, { key: 'className', label: 'Class' }, pctCol('pct')]}
    rows={D.lowAttendance} />
);

// Fee rows with the amount still due and a status
const feeRows = D.studentFees.map((f) => ({
  ...f, due: f.total - f.paid, status: f.total - f.paid === 0 ? 'PAID' : f.paid === 0 ? 'PENDING' : 'PARTIAL',
}));
const feeCols = [
  { key: 'studentId', label: 'ID' }, { key: 'name', label: 'Student' }, { key: 'className', label: 'Class' },
  money('total', 'Total'), money('paid', 'Paid'), money('due', 'Due'), statusCol,
];

const teacherRoster = D.teacherClasses.flatMap((c) =>
  D.teacherStudents[c.id].map((s) => ({ id: s.id, name: s.name, className: c.className, pct: D.teacherStudentPercent[s.id] })));

export const ROLE_ROUTES = {
  STUDENT: [
    { path: '', label: 'Dashboard', icon: '\u{1F3E0}', element: <StudentDashboard /> },
    { path: 'attendance', label: 'My Attendance', icon: '\u{1F4CA}', element: <MyAttendance /> },
    {
      path: 'history', label: 'Attendance History', icon: '\u{1F4C5}',
      element: <DataPage title="Attendance History" columns={[{ key: 'date', label: 'Date' }, { key: 'subject', label: 'Subject' }, statusCol]}
        rows={D.studentHistory} filterKey="subject" filterLabel="Subject" />,
    },
    { path: 'timetable', label: 'Timetable', icon: '\u{1F552}', element: <Timetable /> },
    { path: 'leave', label: 'Leave Request / Status', icon: '\u{1F4DD}', element: <LeaveRequest /> },
    { path: 'notifications', label: 'Notifications', icon: '\u{1F514}', element: notificationsPage },
    {
      path: 'subjects', label: 'Subject Details', icon: '\u{1F4DA}',
      element: <DataPage title="Subject Details" columns={[{ key: 'code', label: 'Code' }, { key: 'name', label: 'Subject' }, { key: 'teacher', label: 'Teacher' }]}
        rows={D.studentSubjects} exportable={false} />,
    },
    {
      path: 'shortage', label: 'Attendance Shortage', icon: '\u26A0\uFE0F',
      element: <DataPage title="Attendance Shortage" subtitle={`Subjects below ${LOW_ATTENDANCE_LIMIT}%`}
        columns={[{ key: 'name', label: 'Subject' }, pctCol('pct', 'Current'), { key: 'needed', label: `Classes to attend in a row to reach ${LOW_ATTENDANCE_LIMIT}%` }]}
        rows={subjectRows.filter((r) => r.pct < LOW_ATTENDANCE_LIMIT)} empty={`Great! No subject is below ${LOW_ATTENDANCE_LIMIT}%.`} searchable={false} exportable={false} />,
    },
    { path: 'profile', label: 'Profile', icon: '\u{1F464}', element: <Profile /> },
  ],

  TEACHER: [
    { path: '', label: 'Dashboard', icon: '\u{1F3E0}', element: <TeacherDashboard /> },
    {
      path: 'classes', label: 'My Classes', icon: '\u{1F3EB}',
      element: <DataPage title="My Classes" columns={[{ key: 'className', label: 'Class' }, { key: 'subject', label: 'Subject' }, { key: 'time', label: 'Time' }, { key: 'room', label: 'Room' }, { key: 'count', label: 'Students' }]}
        rows={D.teacherClasses.map((c) => ({ ...c, count: D.teacherStudents[c.id].length }))} exportable={false} />,
    },
    {
      path: 'subjects', label: 'My Subjects', icon: '\u{1F4DA}',
      element: <DataPage title="My Subjects" columns={[{ key: 'code', label: 'Code' }, { key: 'subject', label: 'Subject' }, { key: 'semester', label: 'Semester' }, { key: 'classes', label: 'Classes' }]}
        rows={D.teacherSubjects} exportable={false} />,
    },
    { path: 'mark-attendance', label: 'Mark Attendance', icon: '\u270D\uFE0F', element: <MarkAttendance /> },
    { path: 'history', label: 'Attendance History', icon: '\u{1F4C5}', element: <AttendanceHistory /> },
    {
      path: 'students', label: 'Student List', icon: '\u{1F465}',
      element: <DataPage title="Student List" columns={[{ key: 'id', label: 'Student ID' }, { key: 'name', label: 'Name' }, { key: 'className', label: 'Class' }, pctCol('pct')]}
        rows={teacherRoster} filterKey="className" filterLabel="Class" />,
    },
    {
      path: 'leave-requests', label: 'Leave Requests', icon: '\u{1F4DD}',
      element: <DataPage title="Student Leave Requests" subtitle="View only. Approval is done by the coordinator." filterKey="status" filterLabel="Status"
        columns={[{ key: 'student', label: 'Student' }, { key: 'className', label: 'Class' }, { key: 'from', label: 'From' }, { key: 'to', label: 'To' }, { key: 'reason', label: 'Reason' }, statusCol]}
        rows={D.teacherLeaveRequests} />,
    },
    {
      path: 'reports', label: 'Reports', icon: '\u{1F4C8}',
      element: <DataPage title="Class and Subject Reports" columns={[{ key: 'className', label: 'Class' }, { key: 'subject', label: 'Subject' }, { key: 'sessions', label: 'Sessions' }, pctCol('average', 'Average'), { key: 'lowCount', label: 'Students below limit' }]}
        rows={D.teacherReports} />,
    },
    { path: 'notifications', label: 'Notifications', icon: '\u{1F514}', element: notificationsPage },
    { path: 'profile', label: 'Profile', icon: '\u{1F464}', element: <Profile /> },
  ],

  COORDINATOR: [
    { path: '', label: 'Dashboard', icon: '\u{1F3E0}', element: <CoordinatorDashboard /> },
    {
      path: 'classes', label: 'Class Management', icon: '\u{1F3EB}',
      element: <DataPage title="Class Management" columns={[{ key: 'className', label: 'Class' }, { key: 'students', label: 'Students' }, { key: 'classTeacher', label: 'Class teacher' }, pctCol('average', 'Average')]} rows={D.classList} />,
    },
    {
      path: 'students', label: 'Student Management', icon: '\u{1F393}',
      element: <DataPage title="Student Management" subtitle="Class allocation" filterKey="className" filterLabel="Class"
        columns={[{ key: 'id', label: 'ID' }, { key: 'name', label: 'Name' }, { key: 'className', label: 'Class' }, statusCol]} rows={D.studentDirectory} />,
    },
    {
      path: 'allocation', label: 'Faculty Allocation', icon: '\u{1F469}\u200D\u{1F3EB}',
      element: <DataPage title="Faculty Allocation" columns={[{ key: 'teacher', label: 'Teacher' }, { key: 'subject', label: 'Subject' }, { key: 'className', label: 'Classes' }]} rows={D.facultyAllocation} />,
    },
    {
      path: 'monitoring', label: 'Attendance Monitoring', icon: '\u{1F4CA}',
      element: <DataPage title="Attendance Monitoring" subtitle="Today's attendance status" filterKey="today" filterLabel="Status"
        columns={[{ key: 'className', label: 'Class' }, { key: 'subject', label: 'Subject' }, { key: 'teacher', label: 'Teacher' }, { key: 'today', label: 'Today', render: (r) => <Badge value={r.today} /> }]} rows={D.attendanceMonitoring} />,
    },
    { path: 'low-attendance', label: 'Low Attendance', icon: '\u26A0\uFE0F', element: lowAttendancePage },
    {
      path: 'leave-monitoring', label: 'Leave Monitoring', icon: '\u{1F4DD}',
      element: <DataPage title="Leave Monitoring" filterKey="status" filterLabel="Status"
        columns={[{ key: 'student', label: 'Student' }, { key: 'className', label: 'Class' }, { key: 'from', label: 'From' }, { key: 'to', label: 'To' }, statusCol]} rows={D.teacherLeaveRequests} />,
    },
    { path: 'timetable', label: 'Timetable', icon: '\u{1F552}', element: <Timetable title="Class Timetable" slots={D.departmentTimetable} /> },
    { path: 'corrections', label: 'Attendance Corrections', icon: '\u270F\uFE0F', element: <ApprovalPage title="Attendance Corrections" subtitle="Approve or reject correction requests." initialRows={D.corrections} /> },
    { path: 'notifications', label: 'Notifications', icon: '\u{1F514}', element: notificationsPage },
    {
      path: 'reports', label: 'Reports', icon: '\u{1F4C8}',
      element: <DataPage title="Semester-wise Reports" columns={[{ key: 'semester', label: 'Semester' }, { key: 'students', label: 'Students' }, pctCol('average', 'Average'), { key: 'lowCount', label: 'Below limit' }]} rows={D.semesterReports} />,
    },
  ],

  ACCOUNTANT: [
    { path: '', label: 'Dashboard', icon: '\u{1F3E0}', element: <AccountantDashboard /> },
    { path: 'student-fees', label: 'Student Fee Records', icon: '\u{1F9FE}', element: <DataPage title="Student Fee Records" columns={feeCols} rows={feeRows} filterKey="status" filterLabel="Status" /> },
    {
      path: 'fee-structure', label: 'Fee Structure', icon: '\u{1F3DB}\uFE0F',
      element: <DataPage title="Fee Structure" columns={[{ key: 'course', label: 'Course / Year' }, money('tuition', 'Tuition'), money('exam', 'Exam'), money('library', 'Library')]} rows={D.feeStructure} exportable={false} />,
    },
    { path: 'record-payment', label: 'Record Payment', icon: '\u{1F4B3}', element: <RecordPayment /> },
    {
      path: 'payment-history', label: 'Payment History', icon: '\u{1F553}',
      element: <DataPage title="Payment History" columns={[{ key: 'receipt', label: 'Receipt' }, { key: 'date', label: 'Date' }, { key: 'studentId', label: 'ID' }, { key: 'name', label: 'Student' }, money('amount', 'Amount'), { key: 'mode', label: 'Mode' }]} rows={D.payments} />,
    },
    {
      path: 'pending', label: 'Pending Fees', icon: '\u23F3',
      element: <DataPage title="Pending Fees" columns={feeCols} rows={feeRows.filter((r) => r.due > 0)} empty="No pending fees." />,
    },
    {
      path: 'receipts', label: 'Receipts', icon: '\u{1F9FE}',
      element: <DataPage title="Generate Receipt" subtitle="Use Print / PDF to save a receipt list." columns={[{ key: 'receipt', label: 'Receipt' }, { key: 'date', label: 'Date' }, { key: 'name', label: 'Student' }, money('amount', 'Amount'), { key: 'mode', label: 'Mode' }]} rows={D.payments} exportable />,
    },
    {
      path: 'reports', label: 'Fee Reports', icon: '\u{1F4C8}',
      element: <DataPage title="Fee Reports" columns={[{ key: 'period', label: 'Period' }, money('collected', 'Collected'), { key: 'transactions', label: 'Transactions' }]} rows={D.feeReports} searchable={false} />,
    },
    {
      path: 'refunds', label: 'Refund Records', icon: '\u21A9\uFE0F',
      element: <DataPage title="Refund Records" filterKey="status" filterLabel="Status" columns={[{ key: 'id', label: 'Refund' }, { key: 'studentId', label: 'ID' }, { key: 'name', label: 'Student' }, money('amount', 'Amount'), { key: 'reason', label: 'Reason' }, statusCol]} rows={D.refunds} />,
    },
    { path: 'notifications', label: 'Notifications', icon: '\u{1F514}', element: notificationsPage },
  ],

  HOD: [
    { path: '', label: 'Dashboard', icon: '\u{1F3E0}', element: <HODDashboard /> },
    {
      path: 'students', label: 'Student Attendance', icon: '\u{1F393}',
      element: <DataPage title="Student Attendance" subtitle="Class-wise summary for your department" columns={[{ key: 'className', label: 'Class' }, { key: 'students', label: 'Students' }, pctCol('average', 'Average')]} rows={D.classList} />,
    },
    {
      path: 'faculty', label: 'Faculty Monitoring', icon: '\u{1F469}\u200D\u{1F3EB}',
      element: <DataPage title="Faculty Monitoring" columns={[{ key: 'teacher', label: 'Teacher' }, { key: 'subjects', label: 'Subjects' }, { key: 'classes', label: 'Classes' }, { key: 'marked', label: 'Sessions marked' }, { key: 'status', label: 'Status', render: (r) => <Badge value={r.status} /> }]} rows={D.facultyMonitoring} />,
    },
    {
      path: 'subjects', label: 'Subject Reports', icon: '\u{1F4DA}',
      element: <DataPage title="Subject Reports" columns={[{ key: 'subject', label: 'Subject' }, { key: 'classes', label: 'Classes' }, pctCol('average', 'Average'), { key: 'lowCount', label: 'Students below limit' }]} rows={D.subjectReports} />,
    },
    { path: 'low-attendance', label: 'Low Attendance', icon: '\u26A0\uFE0F', element: lowAttendancePage },
    { path: 'approvals', label: 'Attendance Approvals', icon: '\u2705', element: <ApprovalPage title="Attendance Approvals" subtitle="Approve or reject correction requests." initialRows={D.corrections} /> },
    {
      path: 'semesters', label: 'Semester Reports', icon: '\u{1F4C8}',
      element: <DataPage title="Semester Reports" columns={[{ key: 'semester', label: 'Semester' }, { key: 'students', label: 'Students' }, pctCol('average', 'Average'), { key: 'lowCount', label: 'Below limit' }]} rows={D.semesterReports} />,
    },
    { path: 'timetable', label: 'Department Timetable', icon: '\u{1F552}', element: <Timetable title="Department Timetable" slots={D.departmentTimetable} /> },
    { path: 'notifications', label: 'Notifications', icon: '\u{1F514}', element: notificationsPage },
  ],

  ADMIN: [
    { path: '', label: 'Dashboard', icon: '\u{1F3E0}', element: <AdminDashboard /> },
    {
      path: 'users', label: 'Users', icon: '\u{1F465}',
      element: <DataPage title="Users" filterKey="role" filterLabel="Role" columns={[{ key: 'loginId', label: 'Login ID' }, { key: 'name', label: 'Name' }, { key: 'role', label: 'Role' }, { key: 'department', label: 'Department' }]}
        rows={D.DEMO_ACCOUNTS.map(({ password, email, ...u }) => u)} />,
    },
    {
      path: 'departments', label: 'Departments', icon: '\u{1F3E2}',
      element: <DataPage title="Departments" columns={[{ key: 'code', label: 'Code' }, { key: 'name', label: 'Department' }, { key: 'hod', label: 'HOD' }, { key: 'students', label: 'Students' }, { key: 'faculty', label: 'Faculty' }]} rows={D.departments} />,
    },
    {
      path: 'settings', label: 'System Settings', icon: '\u2699\uFE0F',
      element: <DataPage title="System Settings" columns={[{ key: 'setting', label: 'Setting' }, { key: 'value', label: 'Value' }]} rows={D.systemSettings} searchable={false} exportable={false} />,
    },
  ],
};
