import { Navigate, Route, Routes } from 'react-router-dom';
import Layout from './components/Layout.jsx';
import ProtectedRoute from './components/ProtectedRoute.jsx';
import { useAuth } from './context/AuthContext.jsx';
import Login from './pages/Login.jsx';
import { ROLE_ROUTES } from './roleConfig.jsx';

function Home() {
  const { user } = useAuth();
  return <Navigate to={user ? `/${user.role.toLowerCase()}` : '/login'} replace />;
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />

      {/* One protected section per role: /student, /teacher, /coordinator, /accountant, /hod, /admin */}
      {Object.entries(ROLE_ROUTES).map(([role, items]) => (
        <Route
          key={role}
          path={`/${role.toLowerCase()}`}
          element={<ProtectedRoute roles={[role]}><Layout /></ProtectedRoute>}
        >
          <Route index element={items[0].element} />
          {items.slice(1).map((i) => <Route key={i.path} path={i.path} element={i.element} />)}
          <Route path="*" element={<Navigate to={`/${role.toLowerCase()}`} replace />} />
        </Route>
      ))}

      <Route path="*" element={<Home />} />
    </Routes>
  );
}
